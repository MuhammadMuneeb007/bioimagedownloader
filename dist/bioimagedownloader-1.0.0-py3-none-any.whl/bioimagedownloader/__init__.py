"""BioImageDownloader package.

Provides the command-line interface entry point and convenience imports.
"""

__all__ = []

